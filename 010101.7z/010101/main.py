import logging
import telebot
import openai
from telebot import types
from telebot.types import *
import requests


API_TOKEN = '6842110579:AAHgvcjW1RYzShLmCeivog_wH_IcuTBRIcs'
openai.api_key = "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"
API_KEY = '34bf668991609b897ce7c8cbb950c152'


bot = telebot.TeleBot(API_TOKEN)

logger = telebot.logger
telebot.logger.setLevel(logging.INFO)


@bot.message_handler(commands=['start'])
def start(message):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    loc= types.KeyboardButton(text="Location", request_location=True)
    pha=types.KeyboardButton("pharmacy")
    con=types.KeyboardButton("contact")
    keyboard.add(loc).add(pha).add(con)
    bot.send_message(message.chat.id,'Bizning Health botizmizga xush kelibsiz!',reply_markup=keyboard)
    bot.send_message(message.chat.id, "Assalomu alaykum! Registratsiyadan o'tish uchun lokatsiyangizni yuboring.", reply_markup=keyboard)

@bot.message_handler(content_types='text')
def message_reply(message):
    if message.text=="pharmacy":
        markup = InlineKeyboardMarkup()
        markup.row_width = 2
        markup.add(InlineKeyboardButton("Grand Pharm", callback_data="Grand Pharm"), InlineKeyboardButton("AA Arzon Apteka", callback_data="AA Arzon Apteka"), InlineKeyboardButton("Uzmed Apteka", callback_data="Uzmed Apteka"), InlineKeyboardButton("Apteka NGMK", callback_data="Apteka NGMK"), InlineKeyboardButton("Xumo Apteka", callback_data="Xumo Apteka"), InlineKeyboardButton("Al-shifo Apteka", callback_data="Al-shifo Apteka"), InlineKeyboardButton("Zarame Apteka", callback_data="Zarame Apteka"), InlineKeyboardButton("Guliy Apteka", callback_data="Guliy Apteka"))
        bot.send_message(message.chat.id,"Dorixonalardan birini tanlang!", reply_markup=markup)
    else:
        response = openai.Completion.create(
            engine="gpt-3.5-turbo-instruct",
            prompt=f"User: {message.text}\nBot: ",
            max_tokens=150,
            temperature=0.7,
            n=1,
            stop=None
        ).choices[0].text

        if len(response)>4096:
            bot.send_message(message.chat.id, response[:4096]+"...")
            bot.send_message(message.chat.id, response[4096:])
        else:
            bot.send_message(message.chat.id, response)





@bot.message_handler(content_types='contact')
def message_reply(message):
    if message.text=="contact":
        markup = InlineKeyboardMarkup()
        markup.row_width = 2
        markup.add(InlineKeyboardButton("+998712311654", callback_data="+998712311654"), InlineKeyboardButton("+998712310394", callback_data="+998712310394"),InlineKeyboardButton("+998555175132", callback_data="+998555175132"))
        bot.send_message(message.chat.id,"Contactlardan birini tanlang!", reply_markup=markup)

    
@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    if call.data == "Grand Pharm":
        city = "Navoiy"
        lat=40.08737532832892, 
        lon=65.37782008361306
        bot.send_location(chat_id=call.message.chat.id, latitude=40.08737532832892, longitude=65.37782008361306)
        response = requests.get.json()

    elif call.data == "AA Arzon Apteka":
        city = "Navoiy"
        lat=40.0874347880781,
        lon=65.37796898541448
        bot.send_location(chat_id=call.message.chat.id, latitude=40.0874347880781, longitude=65.37796898541448)
        response = requests.get.json()
      
    elif call.data == "Uzmed Apteka":
        city = "Navoiy"
        lat=40.09083242854029,
        lon=65.3746859190461
        bot.send_location(chat_id=call.message.chat.id, latitude=40.09083242854029, longitude=65.3746859190461)
        response = requests.get.json()
        
    elif call.data == "Apteka NGMK":
        city = "Navoiy"
        lat=40.099171064737774,
        lon=65.37678877087706
        bot.send_location(chat_id=call.message.chat.id, latitude=40.099171064737774, longitude=65.37678877087706)
        response = requests.get.json()

           
    elif call.data == "Xumo Apteka":
        city = "Navoiy"
        lat=40.106291922789794,
        lon=65.38130328040315
        bot.send_location(chat_id=call.message.chat.id, latitude=40.106291922789794, longitude=65.38130328040315)
        response = requests.get.json()

           
    elif call.data == "Al-shifo Apteka":
        city = "Navoiy"
        lat=40.10563544304591, 
        lon=65.36860033911226
        bot.send_location(chat_id=call.message.chat.id, latitude=40.10563544304591, longitude=65.36860033911226)
        response = requests.get.json()

           
    elif call.data == "Zarame Apteka":
        city = "Navoiy"
        lat=40.0942116813782, 
        lon=40.0942116813782
        bot.send_location(chat_id=call.message.chat.id, latitude=40.0942116813782, longitude=40.0942116813782)
        response = requests.get.json()

           
    elif call.data == "Guliy Apteka":
        city = "Navoiy"
        lat=40.10005510943984,
        lon=65.37598177797048
        bot.send_location(chat_id=call.message.chat.id, latitude=40.10005510943984, longitude=65.37598177797048)
        response = requests.get.json()


if __name__ == '__main__':
    bot.infinity_polling()